# RISC-V-CPU-Core-Project-Using-Verilog

This project is to design a RISC-V core using Verilog in ModelSim , implementing the core components and concepts of RISC-V .
